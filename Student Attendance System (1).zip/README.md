
  # Student Attendance System

  This is a code bundle for Student Attendance System. The original project is available at https://www.figma.com/design/l9xBTQIAEhmWQAPGXhizfQ/Student-Attendance-System.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  