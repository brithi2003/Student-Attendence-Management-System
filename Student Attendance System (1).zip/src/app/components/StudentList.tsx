import { Trash2, UserPlus } from "lucide-react";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { useState } from "react";

export interface Student {
  id: string;
  name: string;
  rollNumber: string;
  email: string;
}

interface StudentListProps {
  students: Student[];
  onAddStudent: (student: Omit<Student, "id">) => void;
  onDeleteStudent: (id: string) => void;
}

export function StudentList({ students, onAddStudent, onDeleteStudent }: StudentListProps) {
  const [isAdding, setIsAdding] = useState(false);
  const [newStudent, setNewStudent] = useState({
    name: "",
    rollNumber: "",
    email: "",
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (newStudent.name && newStudent.rollNumber) {
      onAddStudent(newStudent);
      setNewStudent({ name: "", rollNumber: "", email: "" });
      setIsAdding(false);
    }
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle>Students</CardTitle>
          <Button onClick={() => setIsAdding(!isAdding)} size="sm">
            <UserPlus className="w-4 h-4 mr-2" />
            Add Student
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        {isAdding && (
          <form onSubmit={handleSubmit} className="mb-6 p-4 border rounded-lg bg-muted/50">
            <div className="space-y-3">
              <div>
                <Input
                  placeholder="Student Name"
                  value={newStudent.name}
                  onChange={(e) => setNewStudent({ ...newStudent, name: e.target.value })}
                  required
                />
              </div>
              <div>
                <Input
                  placeholder="Roll Number"
                  value={newStudent.rollNumber}
                  onChange={(e) => setNewStudent({ ...newStudent, rollNumber: e.target.value })}
                  required
                />
              </div>
              <div>
                <Input
                  type="email"
                  placeholder="Email (optional)"
                  value={newStudent.email}
                  onChange={(e) => setNewStudent({ ...newStudent, email: e.target.value })}
                />
              </div>
              <div className="flex gap-2">
                <Button type="submit" size="sm">Add</Button>
                <Button type="button" variant="outline" size="sm" onClick={() => setIsAdding(false)}>
                  Cancel
                </Button>
              </div>
            </div>
          </form>
        )}

        <div className="space-y-2">
          {students.length === 0 ? (
            <p className="text-muted-foreground text-center py-8">No students added yet</p>
          ) : (
            students.map((student) => (
              <div
                key={student.id}
                className="flex items-center justify-between p-3 border rounded-lg hover:bg-muted/50 transition-colors"
              >
                <div className="flex-1">
                  <p className="font-medium">{student.name}</p>
                  <div className="flex gap-4 text-sm text-muted-foreground">
                    <span>Roll: {student.rollNumber}</span>
                    {student.email && <span>{student.email}</span>}
                  </div>
                </div>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => onDeleteStudent(student.id)}
                >
                  <Trash2 className="w-4 h-4 text-destructive" />
                </Button>
              </div>
            ))
          )}
        </div>
      </CardContent>
    </Card>
  );
}
