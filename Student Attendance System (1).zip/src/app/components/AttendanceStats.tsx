import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Student } from "./StudentList";
import { AttendanceRecord } from "./AttendanceMarker";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, Cell } from "recharts";
import { TrendingUp, Users, Calendar } from "lucide-react";

interface AttendanceStatsProps {
  students: Student[];
  attendanceRecords: AttendanceRecord[];
}

export function AttendanceStats({ students, attendanceRecords }: AttendanceStatsProps) {
  const calculateStudentStats = () => {
    return students.map((student) => {
      const studentRecords = attendanceRecords.filter((r) => r.studentId === student.id);
      const presentCount = studentRecords.filter((r) => r.status === "present").length;
      const totalRecords = studentRecords.length;
      const percentage = totalRecords > 0 ? (presentCount / totalRecords) * 100 : 0;

      return {
        name: student.name,
        rollNumber: student.rollNumber,
        present: presentCount,
        absent: totalRecords - presentCount,
        total: totalRecords,
        percentage: percentage.toFixed(1),
      };
    });
  };

  const calculateDailyStats = () => {
    const dateMap = new Map<string, { present: number; absent: number }>();
    
    attendanceRecords.forEach((record) => {
      if (!dateMap.has(record.date)) {
        dateMap.set(record.date, { present: 0, absent: 0 });
      }
      const stats = dateMap.get(record.date)!;
      if (record.status === "present") {
        stats.present++;
      } else {
        stats.absent++;
      }
    });

    return Array.from(dateMap.entries())
      .map(([date, stats]) => ({
        date: new Date(date).toLocaleDateString("en-US", { month: "short", day: "numeric" }),
        present: stats.present,
        absent: stats.absent,
      }))
      .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())
      .slice(-7); // Last 7 days
  };

  const studentStats = calculateStudentStats();
  const dailyStats = calculateDailyStats();

  const totalDays = new Set(attendanceRecords.map((r) => r.date)).size;
  const overallPresent = attendanceRecords.filter((r) => r.status === "present").length;
  const overallAbsent = attendanceRecords.filter((r) => r.status === "absent").length;
  const overallPercentage = overallPresent + overallAbsent > 0
    ? ((overallPresent / (overallPresent + overallAbsent)) * 100).toFixed(1)
    : 0;

  const getPercentageColor = (percentage: number) => {
    if (percentage >= 75) return "text-green-600";
    if (percentage >= 60) return "text-yellow-600";
    return "text-red-600";
  };

  return (
    <div className="space-y-6">
      {/* Overall Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="p-3 bg-blue-100 rounded-lg">
                <Users className="w-6 h-6 text-blue-600" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Total Students</p>
                <p className="text-2xl font-bold">{students.length}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="p-3 bg-purple-100 rounded-lg">
                <Calendar className="w-6 h-6 text-purple-600" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Total Days</p>
                <p className="text-2xl font-bold">{totalDays}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="p-3 bg-green-100 rounded-lg">
                <TrendingUp className="w-6 h-6 text-green-600" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Overall Attendance</p>
                <p className={`text-2xl font-bold ${getPercentageColor(Number(overallPercentage))}`}>
                  {overallPercentage}%
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Daily Attendance Chart */}
      {dailyStats.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Daily Attendance Trend</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={dailyStats}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="date" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Bar dataKey="present" fill="#10b981" name="Present" />
                <Bar dataKey="absent" fill="#ef4444" name="Absent" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      )}

      {/* Student-wise Statistics */}
      {studentStats.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Student-wise Attendance</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {studentStats.map((stat) => (
                <div key={stat.rollNumber} className="space-y-2">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium">{stat.name}</p>
                      <p className="text-sm text-muted-foreground">Roll: {stat.rollNumber}</p>
                    </div>
                    <div className="text-right">
                      <p className={`font-bold ${getPercentageColor(Number(stat.percentage))}`}>
                        {stat.percentage}%
                      </p>
                      <p className="text-sm text-muted-foreground">
                        {stat.present}P / {stat.absent}A / {stat.total}T
                      </p>
                    </div>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div
                      className={`h-2 rounded-full transition-all ${
                        Number(stat.percentage) >= 75
                          ? "bg-green-600"
                          : Number(stat.percentage) >= 60
                          ? "bg-yellow-600"
                          : "bg-red-600"
                      }`}
                      style={{ width: `${stat.percentage}%` }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
