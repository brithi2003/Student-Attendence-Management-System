import { useState, useRef, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Input } from "./ui/input";
import { Button } from "./ui/button";
import { ScrollArea } from "./ui/scroll-area";
import { Send, Bot, User as UserIcon, Minimize2, Maximize2 } from "lucide-react";
import { Student } from "./StudentList";
import { AttendanceRecord } from "./AttendanceMarker";

interface Message {
  id: string;
  role: "user" | "assistant";
  content: string;
  timestamp: Date;
}

interface AIChatbotProps {
  students: Student[];
  attendanceRecords: AttendanceRecord[];
  currentUser?: Student;
  isAdmin: boolean;
}

export function AIChatbot({ students, attendanceRecords, currentUser, isAdmin }: AIChatbotProps) {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "1",
      role: "assistant",
      content: isAdmin
        ? "Hello Admin! I'm your AI assistant. I can help you with attendance statistics, student information, and answer questions about the attendance system. Try asking me about overall attendance, specific students, or recent trends!"
        : `Hello ${currentUser?.name}! I'm your AI assistant. I can help you understand your attendance, answer questions about your records, and provide tips to improve. What would you like to know?`,
      timestamp: new Date(),
    },
  ]);
  const [input, setInput] = useState("");
  const [isMinimized, setIsMinimized] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const generateResponse = (userMessage: string): string => {
    const lowerMessage = userMessage.toLowerCase();

    // Admin-specific responses
    if (isAdmin) {
      // Overall statistics
      if (lowerMessage.includes("overall") || lowerMessage.includes("total") || lowerMessage.includes("all students")) {
        const totalDays = new Set(attendanceRecords.map((r) => r.date)).size;
        const presentCount = attendanceRecords.filter((r) => r.status === "present").length;
        const absentCount = attendanceRecords.filter((r) => r.status === "absent").length;
        const percentage = presentCount + absentCount > 0
          ? ((presentCount / (presentCount + absentCount)) * 100).toFixed(1)
          : 0;
        
        return `Here's the overall attendance summary:\n\n📊 Total Students: ${students.length}\n📅 Total Days Tracked: ${totalDays}\n✅ Total Present: ${presentCount}\n❌ Total Absent: ${absentCount}\n📈 Overall Attendance: ${percentage}%\n\n${Number(percentage) >= 75 ? "Great overall attendance!" : "Consider strategies to improve attendance."}`;
      }

      // Student-specific query
      const studentMatch = students.find(
        (s) => lowerMessage.includes(s.name.toLowerCase()) || lowerMessage.includes(s.rollNumber.toLowerCase())
      );
      if (studentMatch) {
        const studentRecords = attendanceRecords.filter((r) => r.studentId === studentMatch.id);
        const presentCount = studentRecords.filter((r) => r.status === "present").length;
        const totalRecords = studentRecords.length;
        const percentage = totalRecords > 0 ? ((presentCount / totalRecords) * 100).toFixed(1) : 0;

        return `Here's the attendance summary for ${studentMatch.name} (Roll: ${studentMatch.rollNumber}):\n\n✅ Days Present: ${presentCount}\n❌ Days Absent: ${totalRecords - presentCount}\n📅 Total Days: ${totalRecords}\n📈 Attendance Percentage: ${percentage}%\n\n${Number(percentage) >= 75 ? "Excellent attendance!" : Number(percentage) >= 60 ? "Good, but room for improvement." : "Low attendance - may need intervention."}`;
      }

      // Low attendance students
      if (lowerMessage.includes("low attendance") || lowerMessage.includes("poor attendance") || lowerMessage.includes("at risk")) {
        const lowAttendanceStudents = students
          .map((student) => {
            const studentRecords = attendanceRecords.filter((r) => r.studentId === student.id);
            const presentCount = studentRecords.filter((r) => r.status === "present").length;
            const totalRecords = studentRecords.length;
            const percentage = totalRecords > 0 ? (presentCount / totalRecords) * 100 : 100;
            return { student, percentage, totalRecords };
          })
          .filter((s) => s.percentage < 75 && s.totalRecords > 0);

        if (lowAttendanceStudents.length === 0) {
          return "Great news! No students currently have low attendance (below 75%). All students are maintaining good attendance records.";
        }

        const list = lowAttendanceStudents
          .map((s) => `• ${s.student.name} (${s.student.rollNumber}): ${s.percentage.toFixed(1)}%`)
          .join("\n");
        
        return `⚠️ Students with attendance below 75%:\n\n${list}\n\nConsider reaching out to these students to understand any issues they might be facing.`;
      }

      // Recent trends
      if (lowerMessage.includes("recent") || lowerMessage.includes("today") || lowerMessage.includes("this week")) {
        const today = new Date().toISOString().split("T")[0];
        const todayRecords = attendanceRecords.filter((r) => r.date === today);
        
        if (todayRecords.length === 0) {
          return "No attendance has been marked for today yet. Use the 'Mark Attendance' tab to record today's attendance.";
        }

        const presentToday = todayRecords.filter((r) => r.status === "present").length;
        const absentToday = todayRecords.filter((r) => r.status === "absent").length;
        const percentageToday = todayRecords.length > 0
          ? ((presentToday / todayRecords.length) * 100).toFixed(1)
          : 0;

        return `📅 Today's Attendance Summary:\n\n✅ Present: ${presentToday}\n❌ Absent: ${absentToday}\n📊 Total Marked: ${todayRecords.length}/${students.length}\n📈 Attendance Rate: ${percentageToday}%`;
      }
    } else {
      // Student-specific responses
      if (currentUser) {
        const studentRecords = attendanceRecords.filter((r) => r.studentId === currentUser.id);
        const presentCount = studentRecords.filter((r) => r.status === "present").length;
        const totalRecords = studentRecords.length;
        const percentage = totalRecords > 0 ? ((presentCount / totalRecords) * 100).toFixed(1) : 0;

        // My attendance
        if (lowerMessage.includes("my attendance") || lowerMessage.includes("how am i doing") || lowerMessage.includes("my percentage")) {
          return `Here's your attendance summary:\n\n✅ Days Present: ${presentCount}\n❌ Days Absent: ${totalRecords - presentCount}\n📅 Total Days: ${totalRecords}\n📈 Your Attendance: ${percentage}%\n\n${
            Number(percentage) >= 75
              ? "Excellent work! Keep up the great attendance! 🌟"
              : Number(percentage) >= 60
              ? "You're doing okay, but try to improve your attendance to reach 75% or higher."
              : "Your attendance is below the recommended level. Try to attend more regularly to improve your percentage."
          }`;
        }

        // How to improve
        if (lowerMessage.includes("improve") || lowerMessage.includes("better") || lowerMessage.includes("help")) {
          if (Number(percentage) >= 75) {
            return "You're already doing great! Just maintain your current attendance pattern and you'll continue to excel. Keep it up! 🎯";
          }
          
          const daysNeeded = Math.ceil((0.75 * (totalRecords + 10) - presentCount) / 0.75);
          return `To improve your attendance:\n\n1. ✨ Try to attend all upcoming classes\n2. 📅 Plan ahead to avoid absences\n3. 🎯 Set a goal to reach 75% attendance\n4. 💪 Stay motivated and consistent\n\nIf you attend the next ${daysNeeded} classes without absence, you'll significantly improve your percentage!`;
        }

        // Recent attendance
        if (lowerMessage.includes("recent") || lowerMessage.includes("last week") || lowerMessage.includes("this week")) {
          const recentRecords = studentRecords
            .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
            .slice(0, 5);
          
          if (recentRecords.length === 0) {
            return "You don't have any attendance records yet. Your teacher will mark your attendance soon.";
          }

          const recordsList = recentRecords
            .map((r) => {
              const date = new Date(r.date).toLocaleDateString("en-US", { month: "short", day: "numeric" });
              const status = r.status === "present" ? "✅ Present" : "❌ Absent";
              return `• ${date}: ${status}`;
            })
            .join("\n");

          return `Your recent attendance:\n\n${recordsList}`;
        }
      }
    }

    // General responses
    if (lowerMessage.includes("hello") || lowerMessage.includes("hi") || lowerMessage.includes("hey")) {
      return isAdmin
        ? "Hello! How can I assist you with the attendance system today?"
        : `Hi ${currentUser?.name}! How can I help you with your attendance today?`;
    }

    if (lowerMessage.includes("thank")) {
      return "You're welcome! Feel free to ask if you have any other questions. 😊";
    }

    if (lowerMessage.includes("how") && lowerMessage.includes("work")) {
      return isAdmin
        ? "I can help you analyze attendance data, identify trends, find students with low attendance, and answer questions about overall statistics. Try asking about specific students, overall attendance, or students at risk!"
        : "I can help you track your attendance, understand your percentage, and give you tips to improve. Just ask me about your attendance, how to improve, or your recent records!";
    }

    // Default response
    return isAdmin
      ? "I can help you with:\n\n📊 Overall attendance statistics\n👥 Individual student information\n⚠️ Students with low attendance\n📅 Recent attendance trends\n\nTry asking questions like:\n• 'What's the overall attendance?'\n• 'Show me students with low attendance'\n• 'Tell me about Alice Johnson'\n• 'What's today's attendance?'"
      : "I can help you with:\n\n📈 Your attendance percentage\n📅 Recent attendance records\n💡 Tips to improve\n\nTry asking:\n• 'What's my attendance?'\n• 'How can I improve?'\n• 'Show my recent attendance'\n• 'How am I doing?'";
  };

  const handleSend = () => {
    if (!input.trim()) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      role: "user",
      content: input,
      timestamp: new Date(),
    };

    setMessages((prev) => [...prev, userMessage]);

    // Generate AI response
    setTimeout(() => {
      const response = generateResponse(input);
      const assistantMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: "assistant",
        content: response,
        timestamp: new Date(),
      };
      setMessages((prev) => [...prev, assistantMessage]);
    }, 500);

    setInput("");
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  return (
    <Card className="h-full flex flex-col">
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-3">
        <div className="flex items-center gap-2">
          <div className="p-2 bg-purple-100 rounded-lg">
            <Bot className="w-5 h-5 text-purple-600" />
          </div>
          <CardTitle>AI Assistant</CardTitle>
        </div>
        <Button
          variant="ghost"
          size="sm"
          onClick={() => setIsMinimized(!isMinimized)}
        >
          {isMinimized ? <Maximize2 className="w-4 h-4" /> : <Minimize2 className="w-4 h-4" />}
        </Button>
      </CardHeader>

      {!isMinimized && (
        <CardContent className="flex-1 flex flex-col p-0">
          <ScrollArea className="flex-1 p-4" ref={scrollRef}>
            <div className="space-y-4">
              {messages.map((message) => (
                <div
                  key={message.id}
                  className={`flex gap-3 ${
                    message.role === "user" ? "justify-end" : "justify-start"
                  }`}
                >
                  {message.role === "assistant" && (
                    <div className="w-8 h-8 rounded-full bg-purple-100 flex items-center justify-center flex-shrink-0">
                      <Bot className="w-5 h-5 text-purple-600" />
                    </div>
                  )}
                  <div
                    className={`max-w-[80%] rounded-lg p-3 ${
                      message.role === "user"
                        ? "bg-blue-600 text-white"
                        : "bg-muted"
                    }`}
                  >
                    <p className="whitespace-pre-line">{message.content}</p>
                    <p
                      className={`text-xs mt-1 ${
                        message.role === "user" ? "text-blue-100" : "text-muted-foreground"
                      }`}
                    >
                      {message.timestamp.toLocaleTimeString("en-US", {
                        hour: "2-digit",
                        minute: "2-digit",
                      })}
                    </p>
                  </div>
                  {message.role === "user" && (
                    <div className="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center flex-shrink-0">
                      <UserIcon className="w-5 h-5 text-blue-600" />
                    </div>
                  )}
                </div>
              ))}
            </div>
          </ScrollArea>

          <div className="p-4 border-t">
            <div className="flex gap-2">
              <Input
                placeholder="Ask me anything about attendance..."
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyPress={handleKeyPress}
              />
              <Button onClick={handleSend} disabled={!input.trim()}>
                <Send className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </CardContent>
      )}
    </Card>
  );
}
