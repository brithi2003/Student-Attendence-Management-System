import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Student } from "./StudentList";
import { AttendanceRecord } from "./AttendanceMarker";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "./ui/table";
import { Badge } from "./ui/badge";
import { Calendar } from "lucide-react";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { useState } from "react";

interface AttendanceHistoryProps {
  students: Student[];
  attendanceRecords: AttendanceRecord[];
}

export function AttendanceHistory({ students, attendanceRecords }: AttendanceHistoryProps) {
  const [filterDate, setFilterDate] = useState("");

  // Get unique dates and sort them
  const uniqueDates = Array.from(new Set(attendanceRecords.map((r) => r.date)))
    .sort((a, b) => new Date(b).getTime() - new Date(a).getTime());

  const filteredDates = filterDate
    ? uniqueDates.filter((date) => date === filterDate)
    : uniqueDates;

  const getStudentName = (studentId: string) => {
    return students.find((s) => s.id === studentId)?.name || "Unknown";
  };

  const getStudentRoll = (studentId: string) => {
    return students.find((s) => s.id === studentId)?.rollNumber || "N/A";
  };

  const getRecordsForDate = (date: string) => {
    return attendanceRecords.filter((r) => r.date === date);
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle>Attendance History</CardTitle>
          <div className="flex items-center gap-2">
            <Input
              type="date"
              value={filterDate}
              onChange={(e) => setFilterDate(e.target.value)}
              className="w-auto"
            />
            {filterDate && (
              <Button variant="outline" size="sm" onClick={() => setFilterDate("")}>
                Clear
              </Button>
            )}
          </div>
        </div>
      </CardHeader>
      <CardContent>
        {attendanceRecords.length === 0 ? (
          <p className="text-muted-foreground text-center py-8">No attendance records yet</p>
        ) : (
          <div className="space-y-6">
            {filteredDates.map((date) => {
              const records = getRecordsForDate(date);
              const presentCount = records.filter((r) => r.status === "present").length;
              const absentCount = records.filter((r) => r.status === "absent").length;

              return (
                <div key={date} className="border rounded-lg p-4">
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-2">
                      <Calendar className="w-4 h-4 text-muted-foreground" />
                      <h3 className="font-semibold">
                        {new Date(date).toLocaleDateString("en-US", {
                          weekday: "long",
                          year: "numeric",
                          month: "long",
                          day: "numeric",
                        })}
                      </h3>
                    </div>
                    <div className="flex gap-2">
                      <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                        Present: {presentCount}
                      </Badge>
                      <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200">
                        Absent: {absentCount}
                      </Badge>
                    </div>
                  </div>

                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Roll No.</TableHead>
                        <TableHead>Student Name</TableHead>
                        <TableHead>Status</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {records.map((record) => (
                        <TableRow key={`${record.studentId}-${record.date}`}>
                          <TableCell>{getStudentRoll(record.studentId)}</TableCell>
                          <TableCell>{getStudentName(record.studentId)}</TableCell>
                          <TableCell>
                            <Badge
                              variant={record.status === "present" ? "default" : "destructive"}
                              className={
                                record.status === "present"
                                  ? "bg-green-600 hover:bg-green-700"
                                  : ""
                              }
                            >
                              {record.status === "present" ? "Present" : "Absent"}
                            </Badge>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              );
            })}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
