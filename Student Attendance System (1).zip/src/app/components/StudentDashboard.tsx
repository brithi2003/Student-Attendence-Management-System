import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Student } from "./StudentList";
import { AttendanceRecord } from "./AttendanceMarker";
import { Badge } from "./ui/badge";
import { Calendar, TrendingUp, CheckCircle2, XCircle } from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";

interface StudentDashboardProps {
  student: Student;
  attendanceRecords: AttendanceRecord[];
}

export function StudentDashboard({ student, attendanceRecords }: StudentDashboardProps) {
  const studentRecords = attendanceRecords.filter((r) => r.studentId === student.id);
  
  const presentCount = studentRecords.filter((r) => r.status === "present").length;
  const absentCount = studentRecords.filter((r) => r.status === "absent").length;
  const totalDays = studentRecords.length;
  const percentage = totalDays > 0 ? ((presentCount / totalDays) * 100).toFixed(1) : 0;

  const getPercentageColor = (perc: number) => {
    if (perc >= 75) return "text-green-600";
    if (perc >= 60) return "text-yellow-600";
    return "text-red-600";
  };

  // Get last 7 days of attendance
  const recentRecords = studentRecords
    .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
    .slice(0, 7)
    .reverse();

  const chartData = recentRecords.map((record) => ({
    date: new Date(record.date).toLocaleDateString("en-US", { month: "short", day: "numeric" }),
    present: record.status === "present" ? 1 : 0,
    absent: record.status === "absent" ? 1 : 0,
  }));

  return (
    <div className="space-y-6">
      {/* Student Info Card */}
      <Card>
        <CardHeader>
          <CardTitle>Welcome, {student.name}!</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <p className="text-sm text-muted-foreground">Roll Number</p>
              <p className="font-medium">{student.rollNumber}</p>
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Email</p>
              <p className="font-medium">{student.email || "N/A"}</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Statistics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="p-3 bg-green-100 rounded-lg">
                <CheckCircle2 className="w-6 h-6 text-green-600" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Days Present</p>
                <p className="text-2xl font-bold">{presentCount}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="p-3 bg-red-100 rounded-lg">
                <XCircle className="w-6 h-6 text-red-600" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Days Absent</p>
                <p className="text-2xl font-bold">{absentCount}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="p-3 bg-blue-100 rounded-lg">
                <TrendingUp className="w-6 h-6 text-blue-600" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Attendance %</p>
                <p className={`text-2xl font-bold ${getPercentageColor(Number(percentage))}`}>
                  {percentage}%
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Attendance Progress */}
      <Card>
        <CardHeader>
          <CardTitle>Attendance Progress</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span>Overall Progress</span>
              <span className={`font-medium ${getPercentageColor(Number(percentage))}`}>
                {percentage}%
              </span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-3">
              <div
                className={`h-3 rounded-full transition-all ${
                  Number(percentage) >= 75
                    ? "bg-green-600"
                    : Number(percentage) >= 60
                    ? "bg-yellow-600"
                    : "bg-red-600"
                }`}
                style={{ width: `${percentage}%` }}
              />
            </div>
            <p className="text-sm text-muted-foreground">
              {Number(percentage) >= 75
                ? "Great job! You have excellent attendance."
                : Number(percentage) >= 60
                ? "Good attendance, but try to improve."
                : "Warning: Low attendance. Please improve."}
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Recent Attendance Chart */}
      {chartData.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Recent Attendance (Last 7 Days)</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={250}>
              <BarChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="date" />
                <YAxis domain={[0, 1]} ticks={[0, 1]} />
                <Tooltip />
                <Bar dataKey="present" fill="#10b981" name="Present" stackId="a" />
                <Bar dataKey="absent" fill="#ef4444" name="Absent" stackId="a" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      )}

      {/* Detailed Attendance Records */}
      <Card>
        <CardHeader>
          <CardTitle>Attendance History</CardTitle>
        </CardHeader>
        <CardContent>
          {studentRecords.length === 0 ? (
            <p className="text-muted-foreground text-center py-8">No attendance records yet</p>
          ) : (
            <div className="space-y-2">
              {studentRecords
                .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
                .map((record) => (
                  <div
                    key={`${record.date}`}
                    className="flex items-center justify-between p-3 border rounded-lg"
                  >
                    <div className="flex items-center gap-3">
                      <Calendar className="w-4 h-4 text-muted-foreground" />
                      <div>
                        <p className="font-medium">
                          {new Date(record.date).toLocaleDateString("en-US", {
                            weekday: "long",
                            year: "numeric",
                            month: "long",
                            day: "numeric",
                          })}
                        </p>
                      </div>
                    </div>
                    <Badge
                      variant={record.status === "present" ? "default" : "destructive"}
                      className={
                        record.status === "present" ? "bg-green-600 hover:bg-green-700" : ""
                      }
                    >
                      {record.status === "present" ? (
                        <>
                          <CheckCircle2 className="w-3 h-3 mr-1" />
                          Present
                        </>
                      ) : (
                        <>
                          <XCircle className="w-3 h-3 mr-1" />
                          Absent
                        </>
                      )}
                    </Badge>
                  </div>
                ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
