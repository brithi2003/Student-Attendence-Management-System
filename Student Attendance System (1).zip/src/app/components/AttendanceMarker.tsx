import { CheckCircle2, XCircle, Calendar } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Student } from "./StudentList";
import { Badge } from "./ui/badge";

export interface AttendanceRecord {
  studentId: string;
  date: string;
  status: "present" | "absent";
}

interface AttendanceMarkerProps {
  students: Student[];
  date: string;
  onMarkAttendance: (studentId: string, status: "present" | "absent") => void;
  attendanceRecords: AttendanceRecord[];
}

export function AttendanceMarker({
  students,
  date,
  onMarkAttendance,
  attendanceRecords,
}: AttendanceMarkerProps) {
  const getAttendanceStatus = (studentId: string): "present" | "absent" | null => {
    const record = attendanceRecords.find(
      (r) => r.studentId === studentId && r.date === date
    );
    return record ? record.status : null;
  };

  const todayRecords = attendanceRecords.filter((r) => r.date === date);
  const presentCount = todayRecords.filter((r) => r.status === "present").length;
  const absentCount = todayRecords.filter((r) => r.status === "absent").length;

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle>Mark Attendance</CardTitle>
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <Calendar className="w-4 h-4" />
            {new Date(date).toLocaleDateString("en-US", {
              weekday: "long",
              year: "numeric",
              month: "long",
              day: "numeric",
            })}
          </div>
        </div>
        {students.length > 0 && (
          <div className="flex gap-4 mt-2">
            <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
              Present: {presentCount}
            </Badge>
            <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200">
              Absent: {absentCount}
            </Badge>
            <Badge variant="outline" className="bg-gray-50">
              Unmarked: {students.length - presentCount - absentCount}
            </Badge>
          </div>
        )}
      </CardHeader>
      <CardContent>
        {students.length === 0 ? (
          <p className="text-muted-foreground text-center py-8">
            Add students to start marking attendance
          </p>
        ) : (
          <div className="space-y-2">
            {students.map((student) => {
              const status = getAttendanceStatus(student.id);
              return (
                <div
                  key={student.id}
                  className="flex items-center justify-between p-3 border rounded-lg"
                >
                  <div className="flex-1">
                    <p className="font-medium">{student.name}</p>
                    <p className="text-sm text-muted-foreground">Roll: {student.rollNumber}</p>
                  </div>
                  <div className="flex gap-2">
                    <Button
                      variant={status === "present" ? "default" : "outline"}
                      size="sm"
                      onClick={() => onMarkAttendance(student.id, "present")}
                      className={status === "present" ? "bg-green-600 hover:bg-green-700" : ""}
                    >
                      <CheckCircle2 className="w-4 h-4 mr-1" />
                      Present
                    </Button>
                    <Button
                      variant={status === "absent" ? "default" : "outline"}
                      size="sm"
                      onClick={() => onMarkAttendance(student.id, "absent")}
                      className={status === "absent" ? "bg-red-600 hover:bg-red-700" : ""}
                    >
                      <XCircle className="w-4 h-4 mr-1" />
                      Absent
                    </Button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
