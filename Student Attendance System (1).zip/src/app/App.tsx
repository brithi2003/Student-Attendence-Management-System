import { useState, useEffect } from "react";
import { StudentList, Student } from "./components/StudentList";
import { AttendanceMarker, AttendanceRecord } from "./components/AttendanceMarker";
import { AttendanceStats } from "./components/AttendanceStats";
import { AttendanceHistory } from "./components/AttendanceHistory";
import { LoginPage } from "./components/LoginPage";
import { StudentDashboard } from "./components/StudentDashboard";
import { AIChatbot } from "./components/AIChatbot";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./components/ui/tabs";
import { ClipboardCheck, LogOut, MessageCircle } from "lucide-react";
import { Input } from "./components/ui/input";
import { Label } from "./components/ui/label";
import { Button } from "./components/ui/button";
import { Badge } from "./components/ui/badge";

// Sample initial data
const INITIAL_STUDENTS: Student[] = [
  {
    id: "1",
    name: "Alice Johnson",
    rollNumber: "2024001",
    email: "alice@school.edu",
  },
  {
    id: "2",
    name: "Bob Smith",
    rollNumber: "2024002",
    email: "bob@school.edu",
  },
  {
    id: "3",
    name: "Charlie Brown",
    rollNumber: "2024003",
    email: "charlie@school.edu",
  },
];

interface UserSession {
  isAuthenticated: boolean;
  role: "admin" | "student" | null;
  userId: string | null;
}

export default function App() {
  const [userSession, setUserSession] = useState<UserSession>(() => {
    const saved = localStorage.getItem("userSession");
    return saved
      ? JSON.parse(saved)
      : { isAuthenticated: false, role: null, userId: null };
  });

  const [students, setStudents] = useState<Student[]>(() => {
    const saved = localStorage.getItem("students");
    return saved ? JSON.parse(saved) : INITIAL_STUDENTS;
  });

  const [attendanceRecords, setAttendanceRecords] = useState<AttendanceRecord[]>(() => {
    const saved = localStorage.getItem("attendanceRecords");
    return saved ? JSON.parse(saved) : [];
  });

  const [selectedDate, setSelectedDate] = useState<string>(
    new Date().toISOString().split("T")[0]
  );

  const [showChatbot, setShowChatbot] = useState(false);

  // Save to localStorage whenever data changes
  useEffect(() => {
    localStorage.setItem("students", JSON.stringify(students));
  }, [students]);

  useEffect(() => {
    localStorage.setItem("attendanceRecords", JSON.stringify(attendanceRecords));
  }, [attendanceRecords]);

  useEffect(() => {
    localStorage.setItem("userSession", JSON.stringify(userSession));
  }, [userSession]);

  const handleLogin = (username: string, password: string, role: "admin" | "student"): boolean => {
    if (role === "admin") {
      // Admin authentication
      if (username === "admin" && password === "admin123") {
        setUserSession({
          isAuthenticated: true,
          role: "admin",
          userId: "admin",
        });
        return true;
      }
    } else {
      // Student authentication - check if roll number exists and password is correct
      const student = students.find((s) => s.rollNumber === username);
      if (student && password === "student123") {
        setUserSession({
          isAuthenticated: true,
          role: "student",
          userId: student.id,
        });
        return true;
      }
    }
    return false;
  };

  const handleLogout = () => {
    setUserSession({
      isAuthenticated: false,
      role: null,
      userId: null,
    });
    setShowChatbot(false);
    localStorage.removeItem("userSession");
  };

  // Show login page if not authenticated
  if (!userSession.isAuthenticated) {
    return <LoginPage onLogin={handleLogin} />;
  }

  // Get current student if logged in as student
  const currentStudent = userSession.role === "student"
    ? students.find((s) => s.id === userSession.userId)
    : undefined;

  const handleAddStudent = (student: Omit<Student, "id">) => {
    const newStudent: Student = {
      ...student,
      id: Date.now().toString(),
    };
    setStudents([...students, newStudent]);
  };

  const handleDeleteStudent = (id: string) => {
    setStudents(students.filter((s) => s.id !== id));
    // Also remove attendance records for this student
    setAttendanceRecords(attendanceRecords.filter((r) => r.studentId !== id));
  };

  const handleMarkAttendance = (studentId: string, status: "present" | "absent") => {
    // Remove any existing record for this student on this date
    const filteredRecords = attendanceRecords.filter(
      (r) => !(r.studentId === studentId && r.date === selectedDate)
    );

    // Add new record
    const newRecord: AttendanceRecord = {
      studentId,
      date: selectedDate,
      status,
    };

    setAttendanceRecords([...filteredRecords, newRecord]);
  };

  // Render Student Dashboard
  if (userSession.role === "student" && currentStudent) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-50">
        <div className="container mx-auto py-8 px-4 max-w-7xl">
          {/* Header */}
          <div className="mb-8">
            <div className="flex items-center gap-3 mb-2">
              <div className="p-3 bg-blue-600 rounded-lg">
                <ClipboardCheck className="w-8 h-8 text-white" />
              </div>
              <div className="flex-1">
                <h1 className="text-4xl font-bold text-gray-900">
                  Student Portal
                </h1>
                <p className="text-muted-foreground">
                  View your attendance records and statistics
                </p>
              </div>
              <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                Student
              </Badge>
              <Button variant="outline" onClick={handleLogout}>
                <LogOut className="w-4 h-4 mr-2" />
                Logout
              </Button>
            </div>
          </div>

          {/* Main Content */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2">
              <StudentDashboard
                student={currentStudent}
                attendanceRecords={attendanceRecords}
              />
            </div>
            <div className="lg:col-span-1">
              <div className="sticky top-8">
                <AIChatbot
                  students={students}
                  attendanceRecords={attendanceRecords}
                  currentUser={currentStudent}
                  isAdmin={false}
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Render Admin Dashboard
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-50">
      <div className="container mx-auto py-8 px-4 max-w-7xl">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-2">
            <div className="p-3 bg-blue-600 rounded-lg">
              <ClipboardCheck className="w-8 h-8 text-white" />
            </div>
            <div className="flex-1">
              <h1 className="text-4xl font-bold text-gray-900">
                Student Attendance Management
              </h1>
              <p className="text-muted-foreground">
                Track and manage student attendance efficiently
              </p>
            </div>
            <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
              Administrator
            </Badge>
            <Button
              variant="outline"
              onClick={() => setShowChatbot(!showChatbot)}
            >
              <MessageCircle className="w-4 h-4 mr-2" />
              AI Assistant
            </Button>
            <Button variant="outline" onClick={handleLogout}>
              <LogOut className="w-4 h-4 mr-2" />
              Logout
            </Button>
          </div>
        </div>

        {/* Main Content */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className={showChatbot ? "lg:col-span-2" : "lg:col-span-3"}>
            <Tabs defaultValue="mark" className="space-y-6">
              <TabsList className="grid w-full grid-cols-4">
                <TabsTrigger value="mark">Mark Attendance</TabsTrigger>
                <TabsTrigger value="students">Students</TabsTrigger>
                <TabsTrigger value="stats">Statistics</TabsTrigger>
                <TabsTrigger value="history">History</TabsTrigger>
              </TabsList>

              <TabsContent value="mark" className="space-y-4">
                <div className="bg-white p-4 rounded-lg border">
                  <Label htmlFor="date-picker">Select Date</Label>
                  <Input
                    id="date-picker"
                    type="date"
                    value={selectedDate}
                    onChange={(e) => setSelectedDate(e.target.value)}
                    className="max-w-xs mt-2"
                  />
                </div>
                <AttendanceMarker
                  students={students}
                  date={selectedDate}
                  onMarkAttendance={handleMarkAttendance}
                  attendanceRecords={attendanceRecords}
                />
              </TabsContent>

              <TabsContent value="students">
                <StudentList
                  students={students}
                  onAddStudent={handleAddStudent}
                  onDeleteStudent={handleDeleteStudent}
                />
              </TabsContent>

              <TabsContent value="stats">
                <AttendanceStats students={students} attendanceRecords={attendanceRecords} />
              </TabsContent>

              <TabsContent value="history">
                <AttendanceHistory students={students} attendanceRecords={attendanceRecords} />
              </TabsContent>
            </Tabs>
          </div>

          {showChatbot && (
            <div className="lg:col-span-1">
              <div className="sticky top-8">
                <AIChatbot
                  students={students}
                  attendanceRecords={attendanceRecords}
                  isAdmin={true}
                />
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
